#! /bin/sh
dir=/home/ec2-user/
java Server &