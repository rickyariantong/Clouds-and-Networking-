Zip folder contents:

1. Server.java and Server.class: The Server program used to respond to Client 
   requests. Single-threaded.

2. Client.java and Client.class: The modified Client program used to query the
   Server 50 times before stopping.

3. run.sh: Slightly modified version of the shell file shown in the example
   lab worksheets due to technical difficulties in implementation. Still does
   the job - details are covered in the submitted pdf lab report.

4. jokescript.bat: A batch file written for my local Windows terminal used to
   automate the task of running 20 separate Clients each querying the Server
   program. 

5. screenshots (with student id).pdf: pdf file containing screenshots with 
   student id documentation included.  
	