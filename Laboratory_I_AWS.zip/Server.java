/**
 * A simple TCP server. When a client connects, it sends the client a random
 * joke, then closes the connection. This is arguably the simplest server
 * you can write. Beware though that a client has to be completely served the
 * joke (and the client needs to confirm to quit) before the server will be able 
 * to handle another client.
 */

import java.net.*;
import java.io.*;

// this.getId());
// clientSocket.getInetAddress().getHostName()
// clientSocket.getPort());

public class Server {	
	// fields:
	final static int PORT = 5000;
	
	// main method:
	public static void main(String[] args) throws IOException {
		// Initialize sockets:
		ServerSocket listener = null;
		Socket serverSocket = null;
		
		// confirm server startup:
		System.out.println("\nServer starting...");
		
		// start loop:
		try { 
			// listening for requests
			listener = new ServerSocket(PORT); 
			
			while(true) { // server keeps running:
				try { 
					// establishing connection:
					serverSocket = listener.accept();
					String ip = (InetAddress.getLocalHost().getHostAddress());  
					System.out.println("\nNew client connected " + serverSocket.getInetAddress().getHostAddress()); // connection established!
			
					// establish means of communicating with the client:
					DataInputStream fromClient = new DataInputStream(serverSocket.getInputStream());
					DataOutputStream toClient = new DataOutputStream(serverSocket.getOutputStream());
					String clientMessage="";
					
					// prompt client:
					do {
						toClient.writeUTF("\nWould you like to hear a joke ?");
						toClient.flush();
					
						// receive client reply:
						clientMessage = fromClient.readUTF();
						if (!clientMessage.equalsIgnoreCase("N")) {
							toClient.writeUTF(getRandomJoke(ip));
							toClient.flush();
						} // end if
					} while (!clientMessage.equalsIgnoreCase("N")); // end do-while
					
				// +------------------------------------ +
				// | catch #1:                           |
				// |                                     |
				// | only when the client explicitly     |
				// | quits is the connection with the    |
				// | client terminated.                  |
				// + ----------------------------------- +
					
				} catch (Exception e) {
					System.out.println("\nClient: " + serverSocket.getInetAddress().getHostAddress() + " has quit.");
				} // end try-catch
			} // end while
			
			// +-------------------------------------- +
			// | catch #2:                             |
			// |                                       |
			// | provide a means of closing the        |
			// | server sockets - usually an emergency |
			// | measure where the main loop somehow   |
			// | terminates...                         |  
			// + ------------------------------------- +
			
		} catch (Exception e) {
			System.out.println("\nConnection terminated.");
		} finally {
			serverSocket.close();
			listener.close();
		} // end try-catch-finally
	} // end main
	
    public static String getRandomJoke(String ip) {
        // write up jokes:
        String jokes[] = {"\n" + ip + " Joke: Why couldn\'t Jonah trust the ocean?  Because he knew there was something fishy about it.",
        "\n" + ip + " Joke: What did Adam say on the day before Christmas?  It\'s Christmas, Eve!",
        "\n" + ip + " Joke: How does Moses make his coffee?  Hebrews it.",
        "\n" + ip + " Joke: Why did Boaz hate lying?  Because he loved truth.",
        "\n" + ip + " Joke: Which nursery song would Jesus probably have heard the most?  Mary had a little Lamb."};
        
        // return a joke:
        int min = 0, max = 4;
        int position = (int) Math.floor(Math.random()*(max-min+1)+min);
        return jokes[position];
    } // end getRandomJoke
} // end Server