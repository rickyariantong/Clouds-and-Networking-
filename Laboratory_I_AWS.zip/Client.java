import java.net.*;
import java.io.*;

public class Client {
	public static void main(String[] args) {
		try {
			// establishing connection:
			Socket clientSocket = new Socket(args[0], Integer.parseInt(args[1]));
		
			// establish means of communicating with the server:
			DataInputStream fromServer = new DataInputStream(clientSocket.getInputStream());
			DataOutputStream toServer = new DataOutputStream(clientSocket.getOutputStream());
			BufferedReader terminalInput = new BufferedReader(new InputStreamReader(System.in));
			String clientMessage="", serverMessage="";
			
			// engage the server 50 times:
			for (int i = 0; i < 50; ++i) {
				// server: would you like to hear a joke ?
				serverMessage = fromServer.readUTF(); 
				System.out.println(serverMessage);
				
				// client: send response back to server
				clientMessage = "N";
				toServer.writeUTF(serverMessage); 
				toServer.flush();
				
				// display joke:
				serverMessage = fromServer.readUTF();
				System.out.println(serverMessage);
			} // end for
			
			// terminate connection:
			clientSocket.close();
		} catch (Exception e) {
			System.out.println("\nServer terminated connection.");
		} // end try-catch
	} // end main
} // end Client
